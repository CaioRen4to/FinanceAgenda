import { Component } from '@angular/core';

@Component({
  selector: 'app-form-usuario-component',
  imports: [],
  templateUrl: './form-usuario-component.html',
  styleUrl: './form-usuario-component.css'
})
export class FormUsuarioComponent {

}
