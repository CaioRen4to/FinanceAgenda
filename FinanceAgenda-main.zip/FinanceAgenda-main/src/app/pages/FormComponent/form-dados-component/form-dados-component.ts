import { Component } from '@angular/core';

@Component({
  selector: 'app-form-dados-component',
  imports: [],
  templateUrl: './form-dados-component.html',
  styleUrl: './form-dados-component.css'
})
export class FormDadosComponent {

}
