import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-modal-component',
  imports: [],
  templateUrl: './edit-modal-component.html',
  styleUrl: './edit-modal-component.css'
})
export class EditModalComponent {

}
