import { Component } from '@angular/core';

@Component({
  selector: 'app-recursos-visuais',
  imports: [],
  templateUrl: './recursos-visuais.html',
  styleUrl: './recursos-visuais.css'
})
export class RecursosVisuais {

}
