import { Component } from '@angular/core';

@Component({
  selector: 'app-rodape-component',
  imports: [],
  templateUrl: './rodape-component.html',
  styleUrl: './rodape-component.css'
})
export class RodapeComponent {

}
