import { Component } from '@angular/core';

@Component({
  selector: 'app-cabecalho-component',
  imports: [],
  templateUrl: './cabecalho-component.html',
  styleUrl: './cabecalho-component.css'
})
export class CabecalhoComponent {

}
