import { Component } from '@angular/core';

@Component({
  selector: 'app-menu-lateral-component',
  imports: [],
  templateUrl: './menu-lateral-component.html',
  styleUrl: './menu-lateral-component.css'
})
export class MenuLateralComponent {

}
