import { Component } from '@angular/core';

@Component({
  selector: 'app-botao-padro-component',
  imports: [],
  templateUrl: './botao-padro-component.html',
  styleUrl: './botao-padro-component.css'
})
export class BotaoPadroComponent {

}
