import { Component } from '@angular/core';

@Component({
  selector: 'app-card-pardrao-component',
  imports: [],
  templateUrl: './card-pardrao-component.html',
  styleUrl: './card-pardrao-component.css'
})
export class CardPardraoComponent {

}
